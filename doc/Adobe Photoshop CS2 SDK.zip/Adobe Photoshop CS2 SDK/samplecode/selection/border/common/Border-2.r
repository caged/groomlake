// ADOBE SYSTEMS INCORPORATED
// Copyright  1993 - 2002 Adobe Systems Incorporated
// All Rights Reserved
//
// NOTICE:  Adobe permits you to use, modify, and distribute this 
// file in accordance with the terms of the Adobe license agreement
// accompanying it.  If you have received this file from a source
// other than Adobe, then your use, modification, or distribution
// of it requires the prior written permission of Adobe.
//-------------------------------------------------------------------
//-------------------------------------------------------------------------------
//
//	File:
//		FrameSelect.r
//
//
//	Description:
//		Resource information for inset/outset selection
//		sample Automation plug-in.
//
//-------------------------------------------------------------------------------

//-------------------------------------------------------------------------------
//	Definitions -- Required by include files.
//-------------------------------------------------------------------------------

// The About box and resources are created in DialogUtilities.r.
// You can easily override them, if you like.

#define plugInName			"FrameSelect"
#define plugInCopyrightYear	"1998"
#define plugInDescription \
	"An example Actions Module to alter selection in Adobe Photoshop�."

//-------------------------------------------------------------------------------
//	Definitions -- Required by other resources in this rez file.
//-------------------------------------------------------------------------------

// Dictionary (aete) resources:

#define vendorName			"AdobeSDK"
#define plugInAETEComment 	"FrameSelect example actions plug-in"

#define plugInSuiteID		'sdKG'
#define plugInClassID		plugInSuiteID
#define plugInEventID		'frmS'

//-------------------------------------------------------------------------------
//	Set up included files for Macintosh and Windows.
//-------------------------------------------------------------------------------

#include "PIDefines.h"

#ifdef __PIMac__
	#include "Types.r"
	#include "SysTypes.r"
	#include "PIGeneral.r"
	#include "PIUtilities.r"
	#include "DialogUtilities.r"
#elif defined(__PIWin__)
	#include "PIGeneral.h"
	#include "PIUtilities.r"
	#include "WinDialogUtils.r"
#endif

#include "PIActions.h"

#include "FrameSelectTerminology.h"

//-------------------------------------------------------------------------------
//	PiPL resource
//-------------------------------------------------------------------------------

resource 'PiPL' (ResourceID, plugInName " PiPL", purgeable)
	{
		{
		Kind { Actions },
		Name { plugInName "..." },
		Category { vendorName },
		Version { (latestActionsPlugInVersion << 16) | latestActionsPlugInSubVersion },

		#ifdef __PIMac__
			CodeMachOPowerPC { 0, 0, "PluginMain" },
		#elif defined(__PIWin__)
			CodeWin32X86 { "PluginMain" },
		#endif
		
		HasTerminology
			{ 
			plugInClassID, 
			plugInEventID, 
			ResourceID, 
			vendorName " " plugInName	// Unique string.
			},
		
		// If you want this on all the time, remove the EnableInfo property (such
		// as for help menu entries.)  To have this on according to document
		// open, close, and mode guidelines, provide a minimal EnableInfo, such
		// as the one here:
		EnableInfo { "true" },
		
		}
	};

//-------------------------------------------------------------------------------
//	Dictionary (scripting) resource
//-------------------------------------------------------------------------------

resource 'aete' (ResourceID, plugInName " dictionary", purgeable)
	{
	1, 0, english, roman,					/* aete version and language specifiers */
		{
		vendorName,							/* vendor suite name */
		"Adobe example plug-ins",			/* optional description */
		plugInSuiteID,						/* suite ID */
		1,									/* suite code, must be 1 */
		1,									/* suite level, must be 1 */
			{								/* structure for automation */
			plugInName,						/* name */
			plugInAETEComment,				/* optional description */
			plugInClassID,					/* class ID, must be unique or Suite ID */
			plugInEventID,					/* event ID, must be unique */

			NO_REPLY,						/* never a reply */
			IMAGE_DIRECT_PARAMETER,			/* direct parameter, used by Photoshop */
				{							// filter or selection class here:
				// name:
				"offset",
				// key ID:
				keyOffset,
				// type ID:
				typeClass,
				// optional description:
				"",
				// flags:
				flagsOptionalSingleParameter,				
				
				"gutter",
				keyMyGutter,
				typeFloat,
				"",
				flagsOptionalSingleParameter,
				}
			},
			{},	/* non-filter/automation plug-in class here */
			{}, /* comparison ops (not supported) */
			{ // Enumerations go here:
			}	/* end of any enumerations */
		}
	};

//-------------------------------------------------------------------------------
//	Dialog resource
//-------------------------------------------------------------------------------

resource 'DLOG' (uiID, plugInName " UI", purgeable) {
	{190, 203, 450, 523},
	movableDBoxProc,
	visible,
	noGoAway,
	0x0,
	uiID,
	plugInName,
	centerParentWindowScreen
};

resource 'dlgx' (uiID) {
	versionZero {
		kDialogFlagsHandleMovableModal + kDialogFlagsUseThemeControls + kDialogFlagsUseThemeBackground
	}
};

resource 'DITL' (uiID, plugInName " UI", purgeable) {
	{	/* array DITLarray: 18 elements */
		/* [1] */
		{8, 252, 28, 312},
		Button {
			enabled,
			"OK"
		},
		/* [2] */
		{34, 252, 56, 312},
		Button {
			enabled,
			"Cancel"
		},
		/* [3] */
		{9, 12, 29, 64},
		StaticText {
			enabled,
			" Gutter:"
		},
		/* [4] */
		{17, 0, 96, 240},
		UserItem {
			enabled
		},
		/* [5] */
		{34, 36, 54, 108},
		StaticText {
			disabled,
			"Amount:"
		},
		/* [6] */
		{35, 120, 51, 220},
		EditText {
			enabled,
			""
		},
		/* [7] */
		{65, 36, 85, 108},
		StaticText {
			disabled,
			"Units:"
		},
		/* [8] */
		{63, 117, 83, 223},
		Control {
			enabled,
			16001
		},
		/* [9] */
		{101, 12, 121, 64},
		StaticText {
			enabled,
			" Offset:"
		},
		/* [10] */
		{109, 0, 253, 240},
		UserItem {
			enabled
		},
		/* [11] */
		{129, 36, 149, 108},
		StaticText {
			disabled,
			"Top:"
		},
		/* [12] */
		{130, 120, 146, 220},
		EditText {
			enabled,
			""
		},
		/* [13] */
		{161, 36, 181, 108},
		StaticText {
			disabled,
			"Left:"
		},
		/* [14] */
		{162, 120, 178, 220},
		EditText {
			enabled,
			""
		},
		/* [15] */
		{191, 36, 211, 108},
		StaticText {
			disabled,
			"Bottom:"
		},
		/* [16] */
		{192, 120, 208, 220},
		EditText {
			enabled,
			""
		},
		/* [17] */
		{221, 36, 241, 108},
		StaticText {
			disabled,
			"Right:"
		},
		/* [18] */
		{222, 120, 238, 220},
		EditText {
			enabled,
			""
		}
	}
};

resource 'CNTL' (uiID, "Units", purgeable) {
	{16, 4, 36, 110},
	0,
	visible,
	0,
	uiID,
	1016,
	0,
	""
};
resource StringResource (kResetStringID, purgeable)
	{
	"Reset"
	};
	
resource StringResource (kCancelStringID, purgeable)
	{
	"Cancel"
	};

resource StringResource(kUnitsID, purgeable)
{
	"pixels"
};

resource StringResource (kUnitsID+1, purgeable)
{
	"inches"
};

resource StringResource (kUnitsID+2, purgeable)
{
	"cm"
};

resource StringResource (kUnitsID+3, purgeable)
{
	"points"
};

resource StringResource (kUnitsID+4, purgeable)
{
	"picas"
};

resource StringResource (kUnitsID+5, purgeable)
{
	"percent"
};

//-------------------------------------------------------------------------------

// end FrameSelect.r
