// (c) Copyright 1996, 2001.  Adobe Systems, Incorporated.  All rights reserved.
// $Id: //photoshop/9.0/sdk/public/photoshopapi/photoshop/PSErrorDefines.h#1 $ 
// $DateTime: 2005/04/13 13:30:46 $ 
// $Change: 167601 $ 
// $Author: truark $ 

#ifndef __PS_ERROR_DEFINES_H__
#define __PS_ERROR_DEFINES_H__

#if PRAGMA_ONCE
#pragma once
#endif

/* This file exists so that these values can shared with the Rez compiles */

#define errBadTIFFDefine			-25380
#define errNotTIFFDefine			-25390
#define errCompressedTIFFDefine		-25400
#define errBadTIFFDepthDefine		-25410
#define errBadTIFFSpaceDefine		-25420
#define errBadTIFFCCITTT4Define		-25423	
#define errBadTIFFCCITTT6Define		-25427

/* Actions */

#define errEventNotAvailableDefine	-25920
#define errBatchedActionBusyDefine	-25921
#define errReferenceNotFoundDefine	-25922
#define errEventInvalidParametersDefine	-25923
#define errPlayActionBusyDefine		-25930
#define errActionNotFoundDefine		-25940
#define errDeleteActionBusyDefine	-25950


#define errQuadTooBigDefine			-25960
#define errQuadDegenerateDefine		-25970

#endif  /* #ifndef __PS_ERROR_DEFINES_H__ */
