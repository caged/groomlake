// (c) Copyright 2000, 2002-2004.	Adobe Systems, Incorporated.  All rights reserved.
// $Id: $ 
// $DateTime: 2002/09/19 12:30:32 $ 
// $Change: 59675 $ 
// $Author: byer $ 

#ifndef __ASPREINCLUDE__
#define __ASPREINCLUDE__

#if PRAGMA_ONCE
#pragma once
#endif

/******************************************************************************/

#if (!defined(AS_OS) || !defined(AS_ISP))

// Patch for the lame Proximity spelling/hyphenation headers.
#if !defined (EXPORT)
#define EXPORT 2
#endif

#if !defined(USE_STDARG)
#define USE_STDARG	1
#endif

#define PROTOTYPES	1

#if !defined(ENABLE_ZIP)
#define ENABLE_ZIP	1
#endif

#if MacintoshOS
#define AS_OS		asos_mwcw
#define AS_ISP		asisp_ppc603
#define MAC_PLATFORM 1
#endif

#if	MSWindows || defined(__INTEL__) || defined (WIN32)
#define AS_OS		asos_windowsNT
#define AS_ISP		asisp_pentium
#define WIN_PLATFORM 1
#endif

#define WITHIN_PS		0
#define NOT_USE_NATIVE_UTIL_LIBS	0
#define NOT_WITHIN_PS	1

#if !defined(WITHIN_STM)
#define WITHIN_STM		1
#endif

#endif // (!defined(AS_OS) || !defined(AS_ISP))

/******************************************************************************/

// Patch around an old ZStrings suite header for the transition to ADM3.
// SLB 3/26/04
#ifndef kNoErr
#define kNoErr					0
#define kOutOfMemoryErr			'!MEM'
#define kBadParameterErr		'PARM'
#define kNotImplementedErr		'!IMP'
#define kCantHappenErr			'CANT'
#endif

#if MacintoshOS
//typedef unsigned char 	ASBoolean; 
// typedef struct GrafPort* ASWindowRef;
#else
//typedef int 			ASBoolean; 
//typedef void* 			ASWindowRef;			
#endif
//typedef unsigned char 	ASUInt8;
//typedef unsigned short 	ASUInt16;
//typedef unsigned long 	ASUInt32;
//typedef long 			ASErr;
//typedef ASUInt16 		ASUnicode;

/******************************************************************************/

#endif  /* __ASPREINLUDE__ */
