


TIFF 6.0 File Format Specification

The TIFF6.pdf document contains the current TIFF 6.0 specification.

For more information about TIFF, you should refer to the Unofficial TIFF Home Page at:

<http://www-mipl.jpl.nasa.gov/~ndr/tiff/>

maintained by Niles Ritter.  There is a great deal of information on this Web site, including pointers to the TIFF mailing list and TIFF programming resources.

###