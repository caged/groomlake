Welcome to the Adobe Photoshop CS2
Software Development Kit
Macintosh and Windows
Version CS2 ( 9.0 ) (2/4/2005)

_______________________________________________________________________________
What�s new in CS2?

Photoshop is now a MachO binary. Photoshop will still load PEF binary format.
(Code Fragment Manger) See the MachOConversion.pdf document to learn how to 
move your plug-in to the MachO format.

All shipping plug-ins are using the bundle method. You see one file that 
looks like a plug-in but it is actually a bundle with all the parts inside.
See the section below Bundling Plug Ins.

Photoshop File Formats document is updated to reflect new options in version CS2.

32 bit documents, floating point pixels now in Photoshop. See the Dissolve example.

_______________________________________________________________________________
Quick Start to MachO Plug Ins

Get the MachO SDK from the Apple web site. http://www.apple.com.

Get CodeWarrior 9.4 from the Metrowerks web site. http://www.metrowerks.com.

Create new projects, cloning your existing projects, for Mach-O Debug and 
Mach-O Release

In your settings include PIRezMachO.h as the Prefix file for Rez files. Include 
PIMachODebug.h or PIMachOReleas.h for the Prefix file for your C/C++ files.

Add the following to your PiPL resource:

CodeMachOPowerPC { 0, 0, "PluginMain" },

Remove the PEF libraries. Include bundle1.o and MSL_All_Mach-O_D.lib and any
other Mach-O libraries you may need. Compile and Link your projects.


_______________________________________________________________________________
Bundling Plug Ins

Plug ins that ship with Photoshop CS2 are now inside bundles. Below is the 
directory layout for the Dissolve Release plug in. The CodeWarrior project 
settings are given below.

Dissolve/Contents/MacOS/Dissolve
Dissolve/Contents/PkgInfo
Dissolve/Contents/Resources/Dissolve.rsrc

The first item is the actual plug ins. The second item is the package info 
created by Metrowerks and the third item is the resources. All of this was done
by simply changing the PPC Mac OS X Target to Project Type->Bundle Package 
n the Metrowerks projects.

Build both projects and ensure that the folder layout is the same as above.

_______________________________________________________________________________
Metrowerks debugging

Open the Runtime Settings panel in the project. 
Set the Host application to be Photoshop. 

NOTE: CW has a bug where [sometimes] you'll have to close and re-open your 
project after changing the host)

Make a shortcut in the Photoshop plug-in's folder to your plug-in.
Set some break points and choose debug from CodeWarrior

_______________________________________________________________________________
To install

Un-zip the archive. Be sure to keep the folder structure intact.
Documentation requires Acrobat
The documentation included on this kit requires, at minimum, Acrobat Reader to 
view it. To download a copy of Acrobat Reader free of charge, go to 
http://www.adobe.com/.

_______________________________________________________________________________
Metrowerks CodeWarrior

All the Macintosh projects in this SDK were tested in the latest CodeWarrior 
environment, CW Pro 9.2, Release Edition, IDE 5.5.1. 

_______________________________________________________________________________
Microsoft Visual Studio

All the Windows projects in this SDK were tested in the latest Visual Studio 
environment, .NET 2003 v7.1. The custom build step for the .r file usually gets
extra quotation's during the conversion from MSDEV 6.0 projects. Use the 
project properties to fix this conversion error.

_______________________________________________________________________________
Memory

Always ask Photoshop for your memory when you dynamically allocate storage space. 
This can be accomplished by including the PIUNew.cpp file in your project work 
space. This file over rides operator new and delete to call Photoshop memory 
routines. The only dependency is that the SSPBasic* is defined globally as 
sSPBasic.

NOTE: 
If you are running on Photoshop version 4.0 or earlier this is not a valid solution.

_______________________________________________________________________________
C++ exceptions

If you turn on C++ exceptions in your plug in project make sure you wrap all 
of your call backs with try/catch blocks. You do not want to throw back into 
Photoshop. This will cause Photoshop to disappear without a warning to the user. 
Make sure your try/catch blocks are around your PluginMain routine and any OS 
proc, say for your Dialog routine.

_______________________________________________________________________________
Support

Support for the Adobe Photoshop Plug-In API is provided to members of the 
Adobe Solutions Network (ASN) Program.

In the U.S. and Canada, and outside Europe,
the Middle East, Africa, and Japan, contact:
Adobe Solutions Network
Adobe Systems Incorporated
P.O. Box 609
Klamath Falls, OR 97601

For program information:
Tel: +1-800-685-3510(US/Canada only) or +1-206-675-6145
Fax: +1-800-955-1610 or 1+541-880-5075

For membership questions:
E-mail: asndeveloper@adobe.com
Web: http://partners.adobe.com

In Europe, the Middle East, and Africa, contact:
Adobe Solutions Network
Edinburgh EH11 4GJ
Scotland, United Kingdom

For program information:
Tel: +44 131 458 6800
Fax: +44 131 458 6801

For membership questions:
E-mail: euroasn@adobe.com
Web: http://partners.adobe.com

In Japan, contact:
Adobe Solutions Network
Adobe Systems Co., Ltd.
P.O. Box 43, Bunkyo Green Court Post Office
2-28-8 Hon-Komagome, Bunkyo-ku
Tokyo 113-0021 Japan

For program information:
Tel: +81-(0)3-5740-2620
Fax: +81-(0)3-5740-2621

For membership questions:
E-mail: asnjp@adobe.co.jp
Web: http://partners.adobe.com/asn/japan/developer/benefits.html

Development and SDK questions, e-mail: gapdevsup@adobe.com


As always, any plug-ins you create with this SDK can be sold or 
distributed royalty free.
_______________________________________________________________________________

Adobe, Adobe Acrobat, Adobe Photoshop, Adobe PageMaker, Adobe PhotoDeluxe, 
Adobe After Effects, Adobe Premiere, and Adobe Illustrator are trademarks of 
Adobe Systems Incorporated and may be registered in certain jurisdictions. 
Metrowerks and CodeWarrior are registered trademarks of Metrowerks Incorporated. 
Microsoft, Windows, Windows 95, Windows 98, Windows NT, Developer Studio, and 
Visual C++ are trademarks or registered trademarks of Microsoft Corporation. 
Apple is a registered trademark of Apple Computer Incorporated. All other brand 
and product names are trademarks or registered trademarks of their respective 
holders.

Copyright 1989-2005 Adobe Systems Incorporated. All Rights Reserved.

